/*//Boolean:
 #include <iostream>
 int main()
 {
     bool todayistuesday=true;
     bool tomorrowissunday=false;
     std::cout<<todayistuesday<<"\n";
     std::cout<<tomorrowissunday;
     return 0;
 }*/
 
 /*#include <iostream>
 #include <string>
 using namespace std;
int main()
{
    string gpa="My gpa is 3.9.";
    string grade=" My grade is A+.";
    string money=" My parents gifted me $1000.";
    std::cout<<gpa;
    std::cout<<grade;
    std::cout<<money;
    return 0;
}*/

/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string learning="I am learning C++ and it is intresting.";
    std::cout<<learning;
    return 0;
}*/

/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string leapYear="There are 366 days in a leap year.";
    std::cout<<leapYear;
    return 0;
}*/

/* #include <iostream>
 int main()
 {
     const float Pi=3.14;
     std::cout<<Pi;
     return 0;
}*/

/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string days_In_June="There are 31 days in june.";
    std::cout<<days_In_June;
    return 0;
}*/

/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string favorite_subject= "My favorite subject is social studies. ";
    string when_I_have_it= " I have social studies everyday.";
    string my_grade= "I have an A in social studies";
    std::cout<<favorite_subject;
    std::cout<<when_I_have_it;
    std::cout<<my_grade;
    return 0;
}*/

#include <iostream>
int main()
{
    std::cout<<days_In_June;
    return 0;
}
