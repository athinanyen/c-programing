/*#include <iostream>
int main()
{
    int myAge=14;
    std::cout<<"I am "<<myAge<<" years old.";
    return 0;
}*/

/*#include <iostream>
int main()
{
    int firstNum=4;
    int secondNum=3;
    int sum=firstNum+secondNum;
    std::cout<<sum;
    return 0;
}*/

/*#include <iostream>
int main()
{
    int x=3, y=7, z=9;
    std::cout<<x+y+z;
    return 0;
}*/

/*#include <iostream>
int main()
{
    int x, y, z;
    x=y=z=20;
    std::cout<<x+y+z;
    return 0;
}*/

/*#include <iostream>
int main()
{
    double myHeight=5.5;
    std::cout<<"I am "<<myHeight;
    return 0;
}*/

/*#include <iostream>
int main()
{
    double firstNum=3.14;
    std::cout<<"pi ="<<firstNum;
    return 0;
}*/

/*#include <iostream>
int main()
{
    char Angelina= 'A';
    std::cout<<Angelina<<"\n";
    return 0;
}*/

#include <iostream>
int main()
{
    int x, y, z;
    x=y=x=9;
    std::cout<<x-y-z;
    return 0;
}
