/*#include <iostream>
int main ()
{
    char myFirstletter='I';
    char mySecondletter='m';
    char myThirdletter='p';
    char myFourthletter='o';
    char myFifthletter='s';
    char mySixthletter='s';
    char mySeventhletter='i';
    char myEigthletter='b';
    char myNinthletter='l';
    char myTenthletter='e';
    std::cout<<myFirstletter<<"\n";
    std::cout<<mySecondletter<<"\n";
    std::cout<<myThirdletter<<"\n";
    std::cout<<myFourthletter<<"\n";
    std::cout<<myFifthletter<<"\n";
    std::cout<<mySixthletter<<"\n";
    std::cout<<mySeventhletter<<"\n";
    std::cout<<myEigthletter<<"\n";
    std::cout<<myNinthletter<<"\n";
    std::cout<<myTenthletter<<"\n";
    return 0;
}*/
//BooLean:
/*#include <iostream>
int main ()
{
    bool bathroomlighton=true;
    bool stairlighton=true;
    bool kitchenlighton=true;
    bool iswitchedoffthebathroomlight=true;
    bool iswitchedoffthestairlight=true;
    bool iswitchedoffthekitchenlight=false;
    std::cout<<bathroomlighton<<"\n";
    std::cout<<stairlighton<<"\n";
    std::cout<<kitchenlighton<<"\n";
    std::cout<<iswitchedoffthebathroomlight<<"\n";
    std::cout<<iswitchedoffthestairlight<<"\n";
    std::cout<<iswitchedoffthekitchenlight;
    return 0;
}*/
//string:
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string greeting="Today I learned different types of c++ programing language";
    std::cout<<greeting;
    return 0;
}*/
#include <iostream>
int main ()
{
    int price;//
    price=20;//
    std::cout<<20;
    return 0;
}