//create a structure
/*#include <iostream>
#include <string>
int main()
{
    struct{
        int myAge = 14;
        std::string myName;
    } mySelf;
    
    mySelf.myAge= 14;
    mySelf.myName=" My name is Angelina";
    
    std::cout<<mySelf.myName<<"\n";
    std::cout<<mySelf.myAge<<"\n";
    return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
    struct
    {
        std::string name;
        std::string color;
        int weight;
    }fruit1,fruit2,fruit3,fruit4,fruit5;
    fruit1.name="apple ";
    fruit1.color="red ";
    fruit1.weight=30;
     fruit2.name="pineapple ";
    fruit2.color="yellow ";
    fruit2.weight=50;
     fruit3.name="blueberry ";
    fruit3.color="blue ";
    fruit3.weight=10;
     fruit4.name="grape ";
    fruit4.color="purple ";
    fruit4.weight=13;
     fruit5.name="banana ";
    fruit5.color="yellow ";
    fruit5.weight=35;
    std::cout<<fruit1.name<<""<<fruit1.color<<""<<fruit1.weight<<"\n";
    std::cout<<fruit2.name<<""<<fruit2.color<<""<<fruit2.weight<<"\n";
    std::cout<<fruit3.name<<""<<fruit3.color<<""<<fruit3.weight<<"\n";
    std::cout<<fruit4.name<<""<<fruit4.color<<""<<fruit4.weight<<"\n";
    std::cout<<fruit5.name<<""<<fruit5.color<<""<<fruit5.weight<<"\n";
    return 0;
}*/
#include <iostream>
#include <string>
int main()
{
    std::string food="pizza";
    std::string &meal=food;
    std::cout<<food<<"\n";
    std::cout<<meal<<"\n";
    return 0;
}