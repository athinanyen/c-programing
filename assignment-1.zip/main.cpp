//question 1
/*#include <iostream>
int main()
{
    std::cout<<"My name is Angelina.\n";
    std::cout<<"I am coding.\n";
    return 0;
}*/

//question 2
/*#include <iostream>
int main()
{
    int x=3, y=7, z=9;
    std::cout<<x+y+z;
    return 0;
}*/

//question 3
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string leapYear="There are 366 days in a leap year.";
    std::cout<<leapYear;
    return 0;
}*/

//question 4
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    char myFirstletter='E';
    string myInitial="Euro";
    std::cout<<myFirstletter<<"\n";
    std::cout<<myInitial<<"\n";
    return 0;
}*/

//question 5
/*#include <iostream>
int main()
{
    bool on=true;
    bool off=false;
    std::cout<<on<<"\n";
    std::cout<<off;
    return 0;
}*/

//question 6
/*#include <iostream>
int main()
{
    char Math='A';
    char science='A';
    char English='A';
    char Art='A';
    char Health='A';
    std::cout<<Math<<"\n";
    std::cout<<science<<"\n";
    std::cout<<English<<"\n";
    std::cout<<Art<<"\n";
    std::cout<<Health<<"\n";
    return 0;
}*/

//question 7
/*#include <iostream>
#include <string>
int main()
{
    bool egypt=true;
    std::cout<<egypt<<"\n";
    return 0;
}*/

//question 8
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string bye="goodbye\n";
    double num=34.89;
    float done=7.9386283;
    std::cout<<bye;
    std::cout<<num<<"\n";
    std::cout<<done;
    return 0;
}*/

//question 9
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string x;
    std::cout<<"How many minutes are in 5 hours?";
    std::cin>>x;
    std::cout<<"The amount of minutes in 5 hours:"<<x;
    return 0;
}*/

//question 10
/*#include <iostream>
#include <string>
int main()
{
    std::string favSubject;
    std::cout<<"Whats your favorite subject:";
    std::cin>>favSubject;
    std::cout<<"Your favorite subject:"<<favSubject<<"\n";
     std::string classMark;
    std::cout<<"Whats the mark you have in that class:";
    std::cin>>classMark;
    std::cout<<"Your marks obtained:"<<classMark;
    return 0;
}*/

//question 11
/*#include <iostream>
int main()
{
    int x,y;
    int sum;
    int sub;
    int mul;
    int div;
    std::cout<<"Type your first number:";
    std::cin>>x;
    std::cout<<"Type your second number:";
    std::cin>>y;
    sum=x+y;
    std::cout<<"Your sum is:"<<sum<<"\n";
    sub=x-y;
    std::cout<<"your difference is:"<<sub<<"\n";
    mul=x*y;
    std::cout<<"your product is:"<<mul<<"\n";
    div=x/y;
    std::cout<<"your quotient is:"<<div<<"\n";
    return 0;
}*/

//question 12
/*#include <iostream>
#include <string>
int main()
{
    std::string fullSen;
    std::cout<<"";
    std::cin>>fullSen;
    std::cout<<""<<fullSen;
    return 0;
}*/

//question 13
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    std::string firstName="Angelina ";
    std::string secondName="Nguyen";
    std::string fullName= firstName.append(secondName);
    std::cout<<fullName;
    return 0;
}*/

//question 14
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    std::string word="butter";
    std::cout<<word.length();
    return 0;
}*/

//question 15
/*#include <iostream>
#include <string>
int main()
{
    int x=50;
    int y=10;
    std::cout<<std::max(x,y);
    return 0;
}*/
#include <iostream>
#include <string>
int main()
{
    int x=50;
    int y=10;
    std::cout<<std::min(x,y);
    return 0;
}
