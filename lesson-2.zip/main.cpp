/*#include <iostream>
int main()
{
    std::cout<<"Hello\n";
    std::cout<<"Dog\n"; //home
    std::cout<<"Hello coding";
    return 0;
}*/
/*#include <iostream>
int main()
{
    int roblox;
    roblox=17;
    roblox=14;
    std::cout<<"lets game ";
    std::cout<<roblox;
    return 0;
}*/
/*#include <iostream>
int main()
{
    int myAge=14;
    int myHeight=4.6;
    std::cout<<myAge<<"\n";
    std::cout<<myHeight;
    return 0;
}*/
/*#include <iostream>
int main()
{
    double ducks=3.14;
    double trucks=-4.6;
    std::cout<<ducks<<"\n";
    std::cout<<trucks<<"\n";
    return 0;
}*/
#include <iostream>
int main()
{
    char my_First_letter='A';
    char my_Second_letter='n';
    char my_Third_letter='g';
    char my_Fourth_letter='e';
    char my_Fifth_letter='l';
    char my_Sixth_letter='i';
    char my_Seventh_letter='n';
    char my_eighth_letter='a';
    std::cout<<my_First_letter<<my_Second_letter<<my_Third_letter<<my_Fourth_letter<<my_Fifth_letter<<my_Sixth_letter<<my_Seventh_letter<<my_eighth_letter;
    return 0;
}