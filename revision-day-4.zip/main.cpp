//pointers
/*#include <iostream>
int main()
{
    std::string color="pink";
    std::string* ptr=&color;
    std::cout<<color<<"\n";
    std::cout<< &color<<"\n";
    std::cout<<ptr<<"\n";
    return 0;
}*/

//derefrence
/*#include <iostream>
int main()
{
    std::string color="pink";
    std::string* ptr=&color;
    std::cout<<ptr<<"\n";
    std::cout<< *ptr<<"\n";
    return 0;
}*/

