/*#include <iostream>
int main ()
{
    int time=30;
    if(time<9)
    {
    std::cout<<"good morning";
    }
    else if(time<12)
{
    std::cout<<"good afternoon";
}
    else
    
    {
    std::cout<<"good evening";
    }
    return 0;
}*/
/*#include <iostream>
int main ()
{
    int height=6;
    if(height<5)
    {
    std::cout<<"short";
    }
    else if(height<5.3)
{
    std::cout<<"medium";
}
    else
    
    {
    std::cout<<"tall";
    }
    return 0;
}*/
/*#include <iostream>
int main ()
{
    int grade=90;
    if(grade<60)
    {
    std::cout<<"F";
    }
    else if(grade<80)
{
    std::cout<<"B";
}
    else
    
    {
    std::cout<<"A";
    }
    return 0;
}*/
/*#include <iostream>
int main ()
{
    int day=4;
    switch (day)
    {
        case 1:
        std::cout<<"monday";
        break;
        case 2:
        std::cout<<"tuesday";
        break;
        case 3:
        std::cout<<"wenesday";
        break;
        case 4:
        std::cout<<"thurday";
        break;
        case 5:
        std::cout<<"friday";
        break;
        case 6:
        std::cout<<"saturday";
        break;
        case 7:
        std::cout<<"sunday";
    }
    return 0;
}*/

/*#include <iostream>
int main ()
{
    int month=8;
    switch (month)
    {
        case 1:
        std::cout<<"january";
        break;
        case 2:
        std::cout<<"february";
        break;
        case 3:
        std::cout<<"march";
        break;
        case 4:
        std::cout<<"april";
        break;
        case 5:
        std::cout<<"may";
        break;
        case 6:
        std::cout<<"june";
        break;
        case 7:
        std::cout<<"july";
         break;
        case 8:
        std::cout<<"august";
         break;
        case 9:
        std::cout<<"september";
         break;
        case 10:
        std::cout<<"october";
         break;
        case 11:
        std::cout<<"november";
         break;
        case 12:
        std::cout<<"december";
    }
    return 0;
}*/
/*#include <iostream>
int main ()
{
    int vowels=3;
    switch (vowels)
    {
        case 1:
        std::cout<<"a";
        break;
        case 2:
        std::cout<<"e";
        break;
        case 3:
        std::cout<<"i";
        break;
        case 4:
        std::cout<<"o";
        break;
        case 5:
        std::cout<<"u";
    }
    return 0;
}*/
/*#include <iostream>
int main ()
{
    int vowels=6;
    switch (vowels)
    {
        case 1:
        std::cout<<"a";
        break;
        case 2:
        std::cout<<"e";
        break;
        case 3:
        std::cout<<"i";
        break;
        case 4:
        std::cout<<"o";
        break;
        case 5:
        std::cout<<"u";
        default:
        std::cout<<"error";
    }
    return 0;
}*/
#include <iostream>
int main ()
{
    int i=0;
    while (i<100)
    {
        std::cout<<i<<"\n";
        i++;
    }
    return 0;
}