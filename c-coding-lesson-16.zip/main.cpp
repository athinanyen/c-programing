//Access Multi Dimensional
/*#include <iostream>
int main()
{
    std::string letters[2][4]={
        {"A","B","C","D"},
        {"E","F","G","H"}
    };
    std::cout<<letters[0][7];
    return 0;
}*/
/*#include <iostream>
int main()
{
    std::string letters[2][4]={
        {"A","B","C","D"},
        {"E","F","G","H"}
    };
    std::cout<<letters[1][2];
    return 0;
}*/
/*#include <iostream>
int main()
{
    std::string letters[2][4]={
        {"A","B","C","D"},
        {"E","F","G","H"}
    };
    letters[0][0]="X";
    
    std::cout<<letters[1][1];
    return 0;
}*/
/*#include <iostream>
int main()
{
    std::string names[5]={"Angelina","Baodan","Celina","Ethan","Laura"};
    names[0]="Richard";
    std::cout<<names[0];
    return 0;
}*/
//loop through multi dimention
/*#include <iostream>
int main()
{
    std::string letters[2][4]={
        {"A","B","C","D"},
        {"E","F","G","H"}
    };
    for(int i=0;i<2;i++){
        for (int j=0;j<4;j++){
    std::cout<<letters[i][j]<<"\n";
        }
    }
    return 0;
}*/
//3 Dimensional
#include <iostream>
int main()
{
    std::string letters[2][2][2]={
  
    {
        {"A","B"},
        {"C","D"}
    },
    {
        {"W","X"},
        {"Y","Z"}
    }
    };
for(int i=0;i<2;i++)
{
    for (int j=0;j<2;j++)
    {
        for(int k=0;k<2;k++)
        {
            std::cout<<letters[i][j][k]<<"\n";
        }
    
    }
}

    return 0;
}