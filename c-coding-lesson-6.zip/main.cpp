/*#include <iostream>
int main ()
{
    int x;
    std::cout<<"Enter your number:";
    std::cin>>x;
    std::cout<<"Your number:"<<x;
    return 0;
    }*/
    
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string x;
    std::cout<<"Enter your name:";
    std::cin>>x;
    std::cout<<"Your name:"<<x;
    return 0;
}*/

/*#include <iostream>
int main()
{
    int x,y;
    int sum;
    std::cout<<"Type your first number:";
    std::cin>>x;
    std::cout<<"Type your second number:";
    std::cin>>y;
    sum=x+y;
    std::cout<<"Your sum is:"<<sum;
    return 0;
}*/
/*#include <iostream>
int main()
{
   int x,y;
   int sub;
   std::cout<<"How many candy's do you have?";
   std::cin>>x;
   std::cout<<"How many candy's do you give to your brother?";
   std::cin>>y;
   sub=x-y;
   std::cout<<"Amount of candy left:"<<sub;
    return 0;
}*/

/*#include <iostream>
int main()
{
   int x,y;
   int mul;
   std::cout<<"How many bags of cheetos do you have?";
   std::cin>>x;
   std::cout<<"How many cheetos do you want in each bag?";
   std::cin>>y;
   mul=x*y;
   std::cout<<"How many cheetos you have in total:"<<mul;
    return 0;
}*/

/*#include <iostream>
int main()
{
   int x,y;
   int div;
   std::cout<<"How many cheetos do you have?";
   std::cin>>x;
   std::cout<<"How many friends are you gonna give cheetos to?";
   std::cin>>y;
   div=x/y;
   std::cout<<"How many cheetos do they each get? :"<<div;
    return 0;
}*/

/*#include <iostream>
int main()
{
    int x,y;
   int mod;
   std::cout<<"How many cheetos do you have?";
   std::cin>>x;
   std::cout<<"How many friends are you gonna give cheetos to?";
   std::cin>>y;
   mod=x%y;
   std::cout<<"How many cheetos do you give them? :"<<mod;
    return 0;
}*/
//Basic calculator
#include <iostream>
int main()
{
    int x,y;
   int sum;
   int sub;
   int mul;
   int div;
   int mod;
   std::cout<<"Type your first num:";
   std::cin>>x;
   std::cout<<"Type your second num:";
   std::cin>>y;
   sum=x+y;
   std::cout<<"Your sum is:"<<sum<<"\n";
   sub=x-y;
   std::cout<<"Your difference is:"<<sub<<"\n";
   mul=x*y;
   std::cout<<"Your product is:"<<mul<<"\n";
   div=x/y;
   std::cout<<"Your quotient is:"<<div<<"\n";
   mod=x%y;
   std::cout<<"Your modulus is:"<<mod;
   return 0;
}