/*#include <iostream>
#include <string>
int main()
{
    std::string fullName;
    std::cout<<"Type your full name:";
    getline(std::cin,fullName);
    std::cout<<"Your full name is:"<<fullName;
    return 0;
}*/

/*#include <iostream>
#include <string>
int main()
{
    std::string fullName;
    std::cout<<"Type your full name:";
    std::cin>>fullName;
    std::cout<<"Your full name is:"<<fullName;
    return 0;
}*/
//c++ math
/*#include <iostream>
#include <string>
int main()
{
    int x=29;
    int y=75;
    std::cout<<std::max(x,y);
    return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
    int x=29;
    int y=75;
    std::cout<<std::min(29,75);
    return 0;
}*/
/*#include <iostream>
#include <cmath>
int main()
{
    std::cout<<sqrt(29)<<"\n";
    std::cout<<round(6.3)<<"\n";
    std::cout<<log(8)<<"\n";
    return 0;
}*/
//
/*#include <iostream>
int main()
{
    int x=67;
    int y=97;
    if (y>x)
    {
        std::cout<<"y is greater than x";
    }
    return 0;
}*/
/*#include <iostream>
int main()
{
    int x=67;
    int y=97;
    if (y>x)
    {
        std::cout<<"Hello world";
    }
    return 0;
}*/
/*#include <iostream>
int main()
{
    int x=67;
    int y=97;
    if (y>=x)
    {
        std::cout<<"Hello world";
    }
    return 0;
}*/
/*//if else
#include <iostream>
int main()
{
    int time=50;
    if(time<40)
    {
        std::cout<<"good evening";
    }
    else
    {
        std::cout<<"good night";
    }
    return 0;
}*/
/*#include <iostream>
int main()
{
    int thursday=4;
    if(thursday>2)
    {
        std::cout<<"correct";
    }
    else
    {
        std::cout<<"error its wenesday";
    }
    return 0;
}*/