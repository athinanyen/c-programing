/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    std::string code;
    std::cout<<"What do you like?:";
    getline(std::cin,code);
    std::cout<<"You said:"<<code;
    return 0;
}*/
/*#include <iostream>
#include <cmath>
int main()
{
    std::cout<<log(6)<<"\n";
    std::cout<<sqrt(99)<<"\n";
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main()
{
    int num =0;
    cout<<"Enter numbers\n";
    cin>>num;
    while(num>0)
    {
        cout<<"type another number\n";
        cin>>num;
    }
    cout<<"this number was skipped";
    return 0;
}*/
/*#include <iostream>
int main()
{
   int tempature=20;
   if(tempature<10)
   {
       std::cout<<"go to party on saturday";
   }
       else if (tempature<30)
       {
           std::cout<<"stay home and play indoor games";
       }
      else if(tempature<35)
       {
           std::cout<<"go swimming";
       }
       if(tempature<20)
       {
          std::cout<<"go for a picnic";
       }
       return 0;
}*/