//logical operator:
/*#include <iostream>
int main()
{
    int a=40;
    int b=90;
    std::cout<<(b>a&&a<b);
    return 0;
}*/

/*#include <iostream>
int main()
{
    int a=40;
    int b=90;
    std::cout<<(b>a&&a<b);
    std::cout<<(b<a||a>b);
    return 0;
}*/

/*#include <iostream>
int main()
{
    int a=40;
    int b=90;
    std::cout<<!(b>a&&a<b);
    return 0;
}*/
//string:
/*#include <iostream>
int main()
{
    std::string text="Today I am learning about c++ strings.";
    std::cout<<text;
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    std::string firstName="Angelina ";
    std::string secondName="Nguyen";
    std::string fullName= firstName+""+secondName;
    std::cout<<fullName;
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    std::string firstName="Angelina ";
    std::string secondName="Nguyen";
    std::string fullName= firstName.append(secondName);
    std::cout<<fullName;
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    std::string firstName="9";
    std::string secondName="18";
    std::string fullName= firstName+secondName;
    std::cout<<fullName;
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    std::string firstName="i";
    std::string secondName="m";
    std::string thirdName="possible";
    std::string fullName= firstName+secondName+thirdName;
    std::cout<<fullName;
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    std::string word="Pneumonoultramicroscopicsilicovolcanoconiosis";
    std::cout<<word.length();
    return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
    std::string word="impossible";
    std::cout<<word[7];
    return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
    std::string word="ring";
    word[0]='l';
    std::cout<<word;
    return 0;
}*/