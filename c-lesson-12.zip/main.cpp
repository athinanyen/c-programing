//nested loop
/*#include <iostream>
using namespace std;
int main ()
{
    for (int i=1; i<=3;++i)
    {
        cout<<"Outer Loop"<<i<<"\n";
        for (int j=1;j<=5;++j)
        {
            cout<<"inner loop"<<j<<"\n";
        }
    }
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main ()
{
    for (int i=0; i<=5;++i)
    {
        for (int j=0; j<=5;++j)
        {
         std::cout<<i<<j<<"\t";
        }
        std::cout<<"\n";
    }
    
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main ()
{
    for (int i=0; i<=5;++i)
    {
        for (int j=0; j<=5;++j)
        {
            for (int k=0; k<=5;++k)
         std::cout<<i<<j<<k<<"\t";
        }
        std::cout<<"\n";
    }
    
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main ()
{
    int s=1;
    for (int i=1; i<=2;++i)
    {
        for (int j=1; j<=2;++j)
        {
            for (int k=1; k<=2;++k)
            {
         std::cout<<s<<"";
         s=s+1;
            }
        }
        
    }
    
    return 0;
}*/
/*#include <iostream>
using namespace std;
int main ()
{
   for(int i=1;i<=5;++i)
   {
           for(int j=1;j<=i;++j)
           std::cout<<"*";
           std::cout<<"\n";
   }
   return 0;
}*/
#include <iostream>
using namespace std;
int main ()
{
   for(int i=1;i<=5;++i)
   {
           for(int j=1;j<=i;++j)
           std::cout<<"❀";
           std::cout<<"\n";
   }
   return 0;
}