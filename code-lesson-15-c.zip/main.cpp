/*#include <iostream>
int main()
{
    std::string color[4]={"pink","purple","green","yellow"};
    color[3] ="blue";
    std::cout<<color[3];
    return 0;
}*/

/*#include <iostream>
int main()
{
    int myNumbers[5]={10,20,30,40,50};
    for (int i=0;i<sizeof(myNumbers) / sizeof(int); i++)
    {
    std::cout<<myNumbers[i]<<"\n";
    }
    return 0;
}*/
/*#include <iostream>
int main()
{
    int myNumbers[5]={10,20,30,40,50};
    int getArrayLength = sizeof(myNumbers) / sizeof(int);
    std::cout<<getArrayLength;
    return 0;
}*/
/*#include <iostream>
int main()
{
    int myNumbers[5]={1,2,3,4,5};
    for (int i=0;i<sizeof(myNumbers) / sizeof(int); i++)
    {
    std::cout<<myNumbers[i]<<"\n";
    }
    return 0;
}*/
#include <iostream>
int main()
{
    int myNumbers[5]={1,2,3,4,5};
    for (int i=0;i<sizeof(myNumbers) / sizeof(int); i++)
    {
    std::cout<<myNumbers[i]<<"\n";
    }
    return 0;
}