//memory address
/*#include <iostream>
#include <string>
int main()
{
    std::string food="berry";
    std::cout<< &food;
    return 0;
}*/
//pointers
/*#include <iostream>
#include <string>
int main()
{
    std::string food ="pizza";
    std::string* ptr =&food;
    
    //output the value of food
    std::cout<<food<<"\n";
    
    //output the memory address of the food
    std::cout<<&food<<"\n";
    
    //output the memory address of food with the pointer
    std::cout<<ptr<<"\n";
    return 0;
}*/
//difference
/*#include <iostream>
#include <string>
int main()
{
    std::string food ="pizza";
    std::string* ptr =&food;
    
    //refrence : output the memory address of food with the pointer
    std::cout<< ptr <<"\n";
    
    //Derefrence: output the value of food with the pointer
    std::cout<<* ptr <<"\n";
    return 0;
}*/
//modify pointers
/*#include <iostream>
#include <string>
int main()
{
    std::string food ="pizza";
    std::string* ptr =&food;
    
    //Output the value of food
    std::cout<< food <<"\n";
    //output the memory address of food
    std::cout<<&food<<"\n";
    //change the value of the pointer
    *ptr="hamburger";
    //output the new value of the pointer
    std::cout<<* ptr <<"\n";
    //output thr new value of the food varible
    std::cout<<food<<"\n";
    return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
   struct{
       std::string name;
       std::string grade;
   }
   student1, student2, student3;
   student1.name="angelina ";
   student1.grade="A ";
   student2.name="joey ";
   student2.grade="F ";
   student3.name="sam ";
   student3.grade="B";
   std::cout<<student1.name<<student1.grade<<"\n";
   std::cout<<student2.name<<student2.grade<<"\n";
   std::cout<<student3.name<<student3.grade<<"\n";
   return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
   string x,y,w,j,k,l;
   std::cout<<"whats student 1's name? ";
    cout<<"whats there id? ";
   std::cin>>x,y; 
   std::cout<<"whats student 2's name?";
   std::cin>>w;
   cout<<"whats there id?";
   std::cin>>j;
    std::cout<<"whats student 3's name?";
   std::cin>>k;
   cout<<"whats there id?";
   std::cin>>l;
   
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
   std::string color="pink";
   std::string &rainbow=color;
   std::cout<<color<<"\n";
   std::cout<<rainbow<<"\n";
   return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
   std::string color="chocolate donut";
   std::string &brown = color;
   std::cout<<brown<<"\n";
   std::cout<<color;
   return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
   std::string food="chocolate donut";
   std::cout<< &food;
   return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
   std::string food="chocolate donut";
   std::string* ptr=&food;
   std::cout<<ptr<<"\n";
   return 0;
}*/

