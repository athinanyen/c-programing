//cin
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    int age;
    string name;
    cout<<"Enter your name: ";
    cin>>name;
    cout<<"Enter your age: ";
    cin>>age;
    cout<<"Hello, "<<name<<"! You are "<<age<<" years old."<<"\n";
    return 0;
}*/
//string concactenation
/*#include <iostream>
#include <string>
int main()
{
    std::string firstName="Angelina";
    std::string lastName=" Nguyen";
    std::cout<<firstName+lastName;
    return 0;
}*/
//append
/*#include <iostream>
#include <string>
int main()
{
    std::string firstName="Angelina";
    std::string lastName=" Nguyen";
    std::string fullName=firstName.append(lastName);
    std::cout<<fullName;
    return 0;
}*/
//Length
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
   std::string longWord="pneumonoultramicroscopicsilicovolcanoconiosis";
   std::cout<<"The length of the longest word in the world is "<<longWord.length()<<".";
   return 0;
}*/
//size
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
   std::string longWord="pneumonoultramicroscopicsilicovolcanoconiosis";
   std::cout<<"The length of the longest word in the world is "<<longWord.size()<<".";
   return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
   std::string revDay;
   std::cout<<"Today is";
   getline(std::cin,revDay);
   std::cout<<"revision day 2 "<<revDay;
   return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
   std::string word="revision";
   word[0]='d';
   std::cout<<word;
   return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
   std::string word="intelligent";
   std::cout<<word[7];
   return 0;
}*/
/*#include <iostream>
int main()
{
    int a=5;
    int b=7;
    if (a<b);
    std::cout<<"simon says hello";
}*/
/*#include <iostream>
int main()
{
    int marks=100;
    if(marks>90)
    {
        std::cout<<"inteligent";
        
    }
    else
    {
        std::cout<<"Dumb boy";
    }
    return 0;
}*/
//switch
/*#include <iostream>
int
main ()
{
  int day = 2;
  switch (day)
    {
    default:
    case 1:
      std::cout << "monday";
      break;
    case 2:
      std::cout << "tuesday";
      break;
    case 3:
      std::cout << "wenesday";
      break;
    case 4:
    std::cout << "thurday";
   break;
    case 5:
      std::cout << "friday";
         break;
    case 6:
      std::cout << "saturday";
         break;
    case 7:
      std::cout << "sunday";
         break;
         return 0;

    }
}*/
//while loop
/*#include <iostream>
int main()
{
   int i=0;
   while(i<20)
   {
       std::cout<<i<<"\n";
       i++;
   }
   return 0;
}*/
#include <iostream>
int main()
{
   int i=0;
   while(i<20)
   {
       std::cout<<i<<"\n";
       i++;
   }
   return 0;
}
