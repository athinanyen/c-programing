/*#include <iostream>
int main ()
{
    int x,y;
    int sum;
    int sub;
    int mul;
    int div;
    std::cout<<"Type your first num:";
    std::cin>>x;
    std::cout<<"Type yoursecond num:";
    std::cin>>y;
    sum=x+y;
    std::cout<<"your sum is:"<<sum<<"\n";
    sub=x-y;
    std::cout<<"your difference is:"<<sub<<"\n";
    mul=x*y;
    std::cout<<"your product is:"<<mul<<"\n";
    div=x/y;
    std::cout<<"your quotient is:"<<div<<"\n";
    return 0;
}*/
/*#include <iostream>
int main ()
{
    int x=10;
    int y=10;
    ++x;
    --y;
    std::cout<<"increment num is "<<x;
    std::cout<<" Decrement num is"<<y;
    return 0;
}*/
/*#include <iostream>
int main ()
{
    int x=10;
    x=3;
    std::cout<<x<<"\n";
    x+=8;
    std::cout<<x<<"\n";
    x-=6;
    std::cout<<x<<"\n";
    x*=7;
    std::cout<<x<<"\n";
    x/=9;
    std::cout<<x<<"\n";
    x%=6;
    std::cout<<x<<"\n";
    x&=2;
    std::cout<<x<<"\n";
    x|=3;
    std::cout<<x<<"\n";
    x^=2;
    std::cout<<x<<"\n";
    x<<=5;
    std::cout<<x<<"\n";
    x>>=4;
    std::cout<<x<<"\n";
    
    return 0;
}*/

/*#include <iostream>
int main ()
{
    int x=10;
    int y=11;
    std::cout<<(x==y)<<"\n";
    std::cout<<(x!=y)<<"\n";
    std::cout<<(x>y)<<"\n";
    std::cout<<(x<y)<<"\n";
    std::cout<<(x<=y)<<"\n";
    std::cout<<(x>=y)<<"\n";
    return 0;
}*/

/*#include <iostream>
int main ()
{
    int x=10;
    x+=4;
    std::cout<<x<<"\n";
    x|=2;
    std::cout<<x<<"\n";
    return 0;
}*/

