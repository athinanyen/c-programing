//question 1
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    std::string code;
    std::cout<<"What do you like?:";
    getline(std::cin,code);
    std::cout<<"You said:"<<code;
    return 0;
}*/
//question 2
/*#include <iostream>
int main ()
{
    int x=10;
    x&=4;
    std::cout<<x<<"\n";
    x|=2;
    std::cout<<x<<"\n";
    return 0;
}*/
//question 3
/*#include <iostream>
#include <string>
int main()
{
    std::string word="kind";
    word[0]='w';
    std::cout<<word;
    return 0;
}*/
//question 4
/*#include <iostream>
#include <cmath>
int main()
{
    std::cout<<log(9)<<"\n";
    std::cout<<sqrt(84)<<"\n";
    return 0;
}*/
//question 5
/*#include <iostream>
using namespace std;
int main()
{
    int num =0;
    cout<<"Enter numbers\n";
    cin>>num;
    while(num>0)
    {
        cout<<"type another number\n";
        cin>>num;
    }
    cout<<"this number was skipped";
    return 0;
}*/
//question 6
/*#include <iostream>
int main()
{
   int x=20;
   int y=30;
   if(x<y)
   {
       std::cout<<"I am learning if else statments.";
   }
       else if (x<y)
       return 0;
}*/
//question 7
/*#include <iostream>
int main ()
{
    int time=10;
    if(time<9)
    {
    std::cout<<"good morning";
    }
    else if(time<12)
{
    std::cout<<"good afternoon";
}
    return 0;
}*/
//question 8
/*#include <iostream>
int main ()
{
    int height=6;
    if(height<5)
    {
    std::cout<<"short";
    }
    else if(height<5.3)
{
    std::cout<<"medium";
}
    else
    
    {
    std::cout<<"tall";
    }
    return 0;
}*/
//question 9
/*#include <iostream>
int main ()
{
    int day=4;
    switch (day)
    {
        case 1:
        std::cout<<"monday";
        break;
        case 2:
        std::cout<<"tuesday";
        break;
        case 3:
        std::cout<<"wenesday";
        break;
        case 4:
        std::cout<<"thurday";
        break;
        case 5:
        std::cout<<"friday";
        break;
        case 6:
        std::cout<<"saturday";
        break;
        case 7:
        std::cout<<"sunday";
    }
    return 0;
}*/
//question 10
/*#include <iostream>
int main()
{
    int num=1;
    std::cout<<"the first ten numbers are:";
    while(num<=10)
    {
        std::cout<<num<<" ";
        num++;
    }std::cout<<"\n";
}*/
//question 11
/*#include <iostream>
int main ()
{
    int i =1;
    do{
        std::cout<<i<<"\n";
        i++;
    }
    while(i<1);
    return 0;
}*/
//question 12
/*#include <iostream>
int main ()
{
    for (int i=1;i<=99;i=i+2)
    {
        std::cout<<i<<"\n";
    }
    return 0;
}*/
//question 13
/*#include <iostream>
int main ()
{
    for (int i=0;i<5;i++)
    {
        std::cout<<i<<"assignment day\n";
    }
    return 0;
}*/
//question 14
/*#include <iostream>
#include <cmath>
int main()
{
    int sum=0;
    for(int i=1; i<=10; i++)
    {
        sum +=i;
    }
    std::cout<<"the sum of the first ten natrual numbers is:"<<sum<<std"\n";
    return 0;
}*/
//question 15
/*#include <iostream>
int main()
{
    for(int i=1;i<=64;i*=2)
    {
        std::cout<<i<<" ";
    }
    std::cout<<"\n";
    return 0;
}*/
//question 16
/*#include <iostream>
using namespace std;
int main ()
{
   for(int i=1;i<=5;++i)
   {
           for(int j=1;j<=i;++j)
           std::cout<<"+";
           std::cout<<"\n";
   }
   return 0;
}*/
