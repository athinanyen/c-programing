/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string x;
    std::cout<<"How many minutes are in 2 hours?";
    std::cin>>x;
    std::cout<<"The amount of minutes in 2 hours:"<<x;
    return 0;
}*/

/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string x,y;
    std::cout<<"What is your favorite subject?";
    std::cin>>x;
    cout<<"Whats the grade for that subject?";
    std::cin>>y;
    std::cout<<"The favorite subject:"<<x;
    std::cout<<" The grade:"<<y;
    return 0;
}*/
/*#include <iostream>
int main()
{
    int x,y,z;
    x=y=z=20;
    std::cout<<x<<"\n"<<y<<"\n"<<z<<"\n";
    return 0;
}*/
/*#include <iostream>
int main()
{
    int myAge=14;
    double myHeight=5.5;
    std::cout<<"Age="<<myAge;
    std::cout<<" Height="<<myHeight;
    return 0;
}*/
/*//Basic calculator
#include <iostream>
int main()
{
    int x,y;
    int sum;
    int sub;
    int mul;
    int div;
    int mod;
    std::cout<<"Type your first number:";
    std::cin>>x;
    std::cout<<"Type your second number:";
    std::cin>>y;
    sum=x+y;
    std::cout<<"Your sum is:"<<sum<<"\n";
    sub=x-y;
    std::cout<<"your difference is:"<<sub<<"\n";
    mul=x*y;
    std::cout<<"your product is:"<<mul<<"\n";
    div=x/y;
    std::cout<<"your quotient is:"<<div<<"\n";
    mod=x%y;
    std::cout<<"your modulus is:"<<mod<<"\n";
    
    return 0;
}*/
/*#include <iostream>
int main()
{
    std::cout<<"My name is Angelina.\n";
    std::cout<<"I am coding.\n";
    std::cout<<"This is a test.";
    return 0;
}*/
/*#include <iostream>
int main()
{
    int x=50;
    std::cout<<x;
    return 0;
}*/
/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string bye="goodbye";
    std::cout<<bye;
    return 0;
}*/
/*#include <iostream>
int main()
{
    char Math='A';
    char science='A';
    char English='A';
    std::cout<<Math<<"\n";
    std::cout<<science<<"\n";
    std::cout<<English<<"\n";
    return 0;
}*/
/*//Boolean
#include <iostream>
int main()
{
    bool on=true;
    bool off=false;
    std::cout<<on<<"\n";
    std::cout<<off;
    return 0;
}*/
#include <iostream>
#include <string>
using namespace std;
int main()
{
    string hello;
    cin>>hello;
    cout<<hello;
    return 0;
}



