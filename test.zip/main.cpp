/*#include <iostream>
int main()
{
    std::cout<<"Hello World! ";
    std::cout<<"We are testing. ";
    std::cout<<"We are coding. ";

    return 0;
}*/

/*#include <iostream>
int main()
{
    int myNumber;
    myNumber=50;
    std::cout<<myNumber;
    return 0;
}*/

/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string goodbye="Goodbye";
    std::cout<<goodbye;
    return 0;
}*/

/*#include <iostream>
int main()
{
    char myFirstletter='$';
    char mySecondletter='E';
    std::cout<<myFirstletter<<"\n";
    std::cout<<mySecondletter<<"\n";
    return 0;
}*/
/*#include <iostream>
int main()
{
  char Math='A';
  char Science='A';
  char ELA='A';
  std::cout<<Math<<"\n";
  std::cout<<Science<<"\n";
  std::cout<<ELA<<"\n";
  return 0;
}*/
/*//Boolean:
#include <iostream>
int main()
{
    bool yay=true;
    bool nay=false;
    std::cout<<yay<<"\n";
    std::cout<<nay;
    return 0;
}*/
/*#include <iostream>
int main()
{
    int Mood=0;
    std::cout<<Mood<<"\n";
    return 0;
}*/
#include <iostream>
int main()
{
   double num=34.89;
   std::cout<<num;
    return 0;
}


