//do while
/*#include <iostream>
int main()
{
    double num,div=8;
    do{
        std::cout<<"Enter a number"<<"\n";
        std::cin>>num;
        div/=num;
    }
    while(num!=1);
    std::cout<<"Quotient is:"<<div;
    return 0;
}*/
/*#include <iostream>
int main()
{
    int num,sum=8;
    do{
        std::cout<<"Enter a number"<<"\n";
        std::cin>>num;
        sum+=num;
    }
    while(num!=1);
    std::cout<<"sum is:"<<sum;
    return 0;
}*/
//for loop
/*#include <iostream>
int main()
{
    for(int i=2;i<101;i=i+2)
    {
        std::cout<<i<<"\n";
    }
    return 0;
}*/
//nested loops
/*#include <iostream>
int main()
{
    //outer loop
    for(int i=1;i<=2;++i)
    {
        std::cout<<"outer:"<<"\n";
        //inner loop 
        for(int j=1;j<=3;++j)
        {
            std::cout<<"inner:"<<j<<"\n";
        }
    }
    return 0;
}*/
//arrays
/*#include <iostream>
#include <string>
int main()
{
    std::string cars[5] ={"Tesla","bugatti","rolls royce","toyota","jeep"};
    for(int i=0;i<5;i++)
    {
        std::cout<<i<<cars[i]<<"\n";
        
    }
    return 0;
}*/
//looping through multiple dimensions
/*#include <iostream>
int main()
{
 std::string letters[2][2][2] ={
      {
          {"A","b"},
          {"c","d"}
      },
      {
          {"E","f"},
          {"g","h"}
      }
  };
  for(int i=0;i<2;i++){
      for(int j=0;j<2;j++){
          for(int k=0;k<2;k++){
              std::cout<<letters[i][j][k]<<"\n";
          }
      }
  }
  return 0;
}*/
//structures
/*#include <iostream>
#include <string>
int main()
{
    struct{
        std::string dogname;
        std::string breed;
        int age;
    }
    myDog1,myDog2;
    myDog1.dogname="toby";
    myDog1.breed="beagle";
    myDog1.age=3;
    myDog2.dogname="riley";
    myDog2.breed="poodle";
    myDog2.age=2;
    std::cout<<myDog1.dogname<<" "<<myDog1.breed<<" "<<myDog1.age<<"\n";
    std::cout<<myDog2.dogname<< " "<<myDog2.breed<<" "<<myDog2.age<<"\n";
    return 0;
}*/