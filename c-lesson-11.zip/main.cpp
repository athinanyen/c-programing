//while loop
/*#include <iostream>
int main ()
{
    int i=0;
    while(i<100)
    {
        std::cout<<i<<"\n";
        i++;
    }
    return 0;
}*/
/*#include <iostream>
#include <string>
int main ()
{
    int i =0;
    while(i<5)
    {
    std::cout<<"hello world\n";
    i++;
    }
    return 0;
}*/
//do/while loop
/*#include <iostream>
int main ()
{
    int i =0;
    do{
        std::cout<<i<<"\n";
        i++;
    }
    while(i<4);
    return 0;
}*/

/*#include <iostream>
int main ()
{
    int num,product=8;
    do
    {
        std::cout<<"Enter a number:";
        std::cin>>num;
        product*=num;
    }
    while(num!=1);
    std::cout<<"product is "<<product;
    return 0;
}*/
/*#include <iostream>
int main ()
{
    int num,sum=8;
    do
    {
        std::cout<<"Enter a number:";
        std::cin>>num;
        sum+=num;
    }
    while(num!=1);
    std::cout<<"sum is "<<sum;
    return 0;
}*/
/*#include <iostream>
int main ()
{
    double num,div=8;
    do
    {
        std::cout<<"Enter a number:";
        std::cin>>num;
        div/=num;
    }
    while(num!=1);
    std::cout<<"quotient is "<<div;
    return 0;
}*/
/*#include <iostream>
int main ()
{
    int num,sub=8;
    do
    {
        std::cout<<"Enter a number:";
        std::cin>>num;
        sub-=num;
    }
    while(num!=1);
    std::cout<<"difference is "<<sub;
    return 0;
}*/
/*#include <iostream>
int main ()
{
    for (int i=0;i<5;i++)
    {
        std::cout<<i<<"\n";
    }
    return 0;
}*/
/*#include <iostream>
int main ()
{
    for (int i=1;i<11;i++)
    {
        std::cout<<i<<"\n";
    }
    return 0;
}*/
/*#include <iostream>
int main ()
{
    for (int i=1;i<=99;i=i+2)
    {
        std::cout<<i<<"\n";
    }
    return 0;
}*/
/*#include <iostream>
int main ()
{
    for (int i=0;i<5;i++)
    {
        std::cout<<i<<"yes\n";
    }
    return 0;
}*/

