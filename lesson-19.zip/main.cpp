//create a function:
/*void myfunction() //function declaration
{
    //code to be executed //definition
}*/
/*#include <iostream>
void myfunction();
int main()
{
    myfunction();
    return 0;
}
void myfunction()
{
    std::cout<<"where is it at";
}*/
/*#include <iostream>
void day()
{
    std::cout<<"today is saturday.";
}
int main()
{
    day();
}*/
/*#include <iostream>
void things()
{
    std::cout<<"butter in the cake \n";
}
int main()
{
    things();
    things();
    things();
    return 0;
}*/
/*#include <iostream>
void homework()
{
    for(int homework=0;homework<50;homework++)
    std::cout<<"I will do my homework \n";
}
int main()
{
    homework();
    return 0;
}*/
/*#include <iostream>
void myself(std::string fname)
{
    std::cout<<fname<<" Nguyen\n";
}
int main()
{
    myself("Angelina");
    myself("Toby");
    myself("Riley");
    return 0;
}*/
//multiple parimeters
#include <iostream>
void myself(std::string fname,int age)
{
    std::cout<<fname<<" Nguyen."<<age<<" Years old\n";
}
int main()
{
    myself("Angelina",14);
    myself("Toby",3);
    myself("Riley",2);
    return 0;
}