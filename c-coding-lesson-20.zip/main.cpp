//return values
/*#include <iostream>
int myFunction(int x)
{
    return 8 + x;
    
}
int main()
{
std::cout<<myFunction(2);
return 0;
}*/
/*#include <iostream>
int myFunction(int a, int b, int c, int d)
{
    return a-b+c*d;
}
int main()
{
    std::cout<<myFunction(8,6,7,2);
    return 0;
}*/
//pass array to a function
/*#include <iostream>
void myFunction(int myNum[5])
{
    for (int i=0; i <5; i++)
    {
        std::cout<<myNum[i]<<"\n";
    }
}
int main()
{
    int myNum[5]={1,2,3,4,5};
    myFunction(myNum);
    return 0;
    
}*/
//recursion:
/*#include <iostream>
int sum(int k)
{
    if(k>0)
    {
        return k + sum(k-1);
    }
    else
    {
        return 0;
    }
}
int main()
{
    int result=sum(10);
    std::cout<<result;
    return 0;
}*/
//revision day 1
/*#include <iostream>
using namespace std;
int main()
{
    int a=58;
    int y=84;
    std::cout<<(!(a>6 && y>9));
    return 0;
}*/
#include <iostream>
#include <string>
using namespace std;
int main()
{
    int number;
    std::cout<<"enter a number: ";
    std::cin>> number;
    std::cout<<" You entered:"<< number<<"\n";
    return 0;
}
