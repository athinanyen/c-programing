//nested loop
/*#include <iostream>
int main ()
{
    
for (int i=1;i<=3;++i)
{
    std::cout<<"outer:"<<i<<"\n";
    
for(int j=1;j<=4;++j)
    {
    std::cout<<"inner:"<<j<<"\n";
    }
}
    return 0;
}*/
/*#include <iostream>
int main ()
{
    for(int i=0;i<=5;++i)
    {
        for(int j=0;j<=5;++j)
        {
            std::cout<<i<<j<<"\t";
        }
        std::cout<<"\n";
    }
}*/
/*#include <iostream>
int main ()
{
    for(int i=1;i<=20;++i)
    {
        for(int j=1;j<=i;++j)
        {
            std::cout<<"*";
        }
        std::cout<<"\n";
    }
}*/
#include <iostream>
int main ()
{
    for(int i=0;i<=10;i++){
        if(i==4)
        {
            continue;
        }
        std::cout<<i<<"\n";
    }
    return 0;
}