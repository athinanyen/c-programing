/*#include <iostream>
int main()
{
    std::string colors[4]={"pink", "blue","red","green"};
    std::cout<<colors[1];
    return 0;
}*/

/*#include <iostream>
int main()
{
    std::string colors[4]={"pink", "blue","red","green"};
    for(int i=0;i<5;i++)
    {
    std::cout<<colors[i]<<"\n";
    }
    return 0;
}*/
#include <iostream>
int main()
{
    std::string colors[5]={" pink", " blue"," red"," green"," purple"};
    for(int i=0;i<5;i++)
    {
    std::cout<<i<<colors[i]<<"\n";
    }
    return 0;
}